(function () {
  const ui = window.SmartRoute;
  const cfg = window.SmartRouteConfig;

  function checkoutState() {
    try {
      return JSON.parse(localStorage.getItem(cfg.checkoutKey));
    } catch (error) {
      return null;
    }
  }

  function bookingFuture(booking) {
    const schedule = booking.schedule;
    if (!schedule) return false;
    return new Date(`${schedule.travelDate}T${schedule.departureTime}`) > new Date();
  }

  function canCancel(booking) {
    return ["PENDING_PAYMENT", "CONFIRMED"].includes(booking.bookingStatus) && bookingFuture(booking);
  }

  function canReview(booking) {
    return ["CONFIRMED", "COMPLETED"].includes(booking.bookingStatus);
  }

  function summaryRows(booking, payment, receipt) {
    const schedule = booking.schedule;
    return `
      <div class="detail-grid">
        <div class="detail"><span>Booking reference</span><strong>${ui.escapeHtml(booking.bookingReference)}</strong></div>
        <div class="detail"><span>Passenger</span><strong>${ui.escapeHtml(ui.fullName(booking.passengerUser))}</strong></div>
        <div class="detail"><span>Route</span><strong>${ui.escapeHtml(ui.routeLabel(schedule))}</strong></div>
        <div class="detail"><span>Travel date</span><strong>${ui.date(schedule.travelDate)}</strong></div>
        <div class="detail"><span>Departure</span><strong>${ui.time(schedule.departureTime)}</strong></div>
        <div class="detail"><span>Arrival</span><strong>${ui.time(schedule.arrivalTime)}</strong></div>
        <div class="detail"><span>Bus registration</span><strong>${ui.escapeHtml(schedule.bus.registrationNo)}</strong></div>
        <div class="detail"><span>Seats</span><strong>${ui.escapeHtml(ui.seatsLabel(booking.seats))}</strong></div>
        <div class="detail"><span>Total amount</span><strong>${ui.money(booking.totalAmount)}</strong></div>
        <div class="detail"><span>Payment method</span><strong>${ui.escapeHtml((payment && payment.paymentMethod) || (receipt && receipt.paymentMethod) || "Not available")}</strong></div>
        <div class="detail"><span>Booking status</span>${ui.badge(booking.bookingStatus)}</div>
        <div class="detail"><span>Payment status</span>${payment ? ui.badge(payment.paymentStatus) : "<strong>Not available</strong>"}</div>
      </div>`;
  }

  function initCheckout() {
    if (!window.Auth.requireAuth({ roles: ["PASSENGER"] })) return;
    const state = checkoutState();
    if (!state || !state.scheduleId || !state.seats || !state.seats.length) {
      ui.showAlert("#pageAlert", "warning", "Select seats before checkout.");
      ui.$("#checkoutContent").innerHTML = `<div class="empty-state"><a class="btn btn-primary" href="/index.html">Search schedules</a></div>`;
      return;
    }
    const schedule = state.schedule;
    ui.$("#checkoutSummary").innerHTML = `
      <div class="detail-grid">
        <div class="detail"><span>Route</span><strong>${ui.escapeHtml(ui.routeLabel(schedule))}</strong></div>
        <div class="detail"><span>Travel date</span><strong>${ui.date(schedule.travelDate)}</strong></div>
        <div class="detail"><span>Departure</span><strong>${ui.time(schedule.departureTime)}</strong></div>
        <div class="detail"><span>Selected seats</span><strong>${ui.escapeHtml(state.seats.join(", "))}</strong></div>
        <div class="detail"><span>Passengers</span><strong>${state.seats.length}</strong></div>
        <div class="detail"><span>Total payment</span><strong>${ui.money(state.total)}</strong></div>
      </div>`;

    const refInput = ui.$('[name="transactionReference"]');
    if (refInput) refInput.value = window.Payments.transactionReference();
    const form = ui.$("#checkoutForm");
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const button = form.querySelector("button[type=submit]");
      ui.setLoading(button, true, "Processing");
      ui.showAlert("#pageAlert", "", "");
      try {
        const data = ui.formData(form);
        const booking = await window.Api.post("/bookings", {
          scheduleId: state.scheduleId,
          seatNumbers: state.seats
        });
        const payment = await window.Payments.payBooking(booking.bookingId, {
          transactionReference: data.transactionReference,
          paymentMethod: data.paymentMethod,
          simulateFailure: data.simulateFailure === "on"
        });
        localStorage.setItem(cfg.bookingKey, JSON.stringify({ booking, payment }));
        localStorage.removeItem(cfg.checkoutKey);
        if (payment.paymentStatus === "SUCCESS") {
          window.location.assign(`/ticket.html?bookingId=${booking.bookingId}&paymentId=${payment.paymentId}`);
        } else {
          ui.showAlert("#pageAlert", "warning", "Payment did not succeed. The unpaid booking was cancelled and the selected seats were released.");
        }
      } catch (error) {
        ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
      } finally {
        ui.setLoading(button, false);
      }
    });
  }

  async function initTicket() {
    if (!window.Auth.requireAuth()) return;
    const params = new URLSearchParams(window.location.search);
    const saved = (() => {
      try { return JSON.parse(localStorage.getItem(cfg.bookingKey)); } catch (error) { return null; }
    })();
    const bookingId = params.get("bookingId") || (saved && saved.booking && saved.booking.bookingId);
    const paymentId = params.get("paymentId") || (saved && saved.payment && saved.payment.paymentId);
    if (!bookingId) {
      ui.$("#ticketContent").innerHTML = `<div class="empty-state">No booking id was provided.</div>`;
      return;
    }
    try {
      const booking = await window.Api.get(`/bookings/${bookingId}`);
      let payment = null;
      let receipt = null;
      if (paymentId) {
        try {
          payment = await window.Payments.verify(paymentId);
        } catch (error) {
          payment = saved && saved.payment ? saved.payment : null;
        }
      }
      try {
        receipt = await window.Payments.receipt(bookingId);
      } catch (error) {
        receipt = null;
      }
      ui.$("#ticketContent").innerHTML = `
        <article class="ticket">
          <div class="ticket-head">
            <p class="eyebrow">SmartRoute Lanka</p>
            <h1>${ui.escapeHtml(booking.bookingReference)}</h1>
          </div>
          <div class="ticket-body">${summaryRows(booking, payment, receipt)}</div>
        </article>`;
      ui.$("#printBtn").addEventListener("click", () => window.print());
    } catch (error) {
      ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
    }
  }

  async function loadReviewsMap() {
    try {
      const data = await window.Api.get("/reviews/my", { size: 100 });
      return new Map((data.content || []).map((review) => [review.bookingId, review]));
    } catch (error) {
      return new Map();
    }
  }

  async function loadMyBookings(page) {
    const list = ui.$("#bookingsList");
    list.innerHTML = `<div class="empty-state"><span class="spinner"></span> Loading bookings...</div>`;
    try {
      const [data, reviews] = await Promise.all([
        window.Api.get("/bookings/my", { page: page || 0, size: cfg.defaultPageSize }),
        loadReviewsMap()
      ]);
      if (!data.content || data.content.length === 0) {
        list.innerHTML = `<div class="empty-state">You do not have any bookings yet.</div>`;
        ui.pagination("#bookingsPagination", data, loadMyBookings);
        return;
      }
      list.innerHTML = `
        <div class="table-wrap card flush">
          <table>
            <thead><tr><th>Reference</th><th>Route</th><th>Date and time</th><th>Seats</th><th>Total</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              ${data.content.map((booking) => `
                <tr>
                  <td>${ui.escapeHtml(booking.bookingReference)}</td>
                  <td>${ui.escapeHtml(ui.routeLabel(booking.schedule))}</td>
                  <td>${ui.date(booking.schedule.travelDate)} ${ui.time(booking.schedule.departureTime)}</td>
                  <td>${ui.escapeHtml(ui.seatsLabel(booking.seats))}</td>
                  <td>${ui.money(booking.totalAmount)}</td>
                  <td>${ui.badge(booking.bookingStatus)}</td>
                  <td>
                    <div class="actions">
                      <a class="btn btn-small btn-ghost" href="/ticket.html?bookingId=${booking.bookingId}">Ticket</a>
                      ${canCancel(booking) ? `<button class="btn btn-small btn-danger" data-cancel="${booking.bookingId}" type="button">Cancel</button>` : ""}
                      ${canReview(booking) && !reviews.has(booking.bookingId) ? `<a class="btn btn-small btn-primary" href="/review.html?bookingId=${booking.bookingId}">Review</a>` : ""}
                      ${reviews.has(booking.bookingId) ? `<span class="status-pill status-success">Reviewed</span>` : ""}
                    </div>
                  </td>
                </tr>`).join("")}
            </tbody>
          </table>
        </div>`;
      ui.$all("[data-cancel]").forEach((button) => {
        button.addEventListener("click", async () => {
          if (!confirm("Cancel this booking? Reserved seats will be released.")) return;
          try {
            await window.Api.patch(`/bookings/${button.dataset.cancel}/cancel`, null);
            ui.showAlert("#pageAlert", "success", "Booking cancelled.");
            loadMyBookings(page || 0);
          } catch (error) {
            ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
          }
        });
      });
      ui.pagination("#bookingsPagination", data, loadMyBookings);
    } catch (error) {
      list.innerHTML = "";
      ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
    }
  }

  document.addEventListener("DOMContentLoaded", () => {
    const page = document.body.dataset.page;
    if (page === "checkout") initCheckout();
    if (page === "ticket") initTicket();
    if (page === "my-bookings" && window.Auth.requireAuth({ roles: ["PASSENGER"] })) loadMyBookings(0);
  });
})();
