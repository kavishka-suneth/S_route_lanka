(function () {
  const ui = window.SmartRoute;
  function render(data) {
    const node = ui.$("#notificationsList");
    if (!data.content || !data.content.length) { node.innerHTML = '<div class="empty-state">No notifications yet.</div>'; return; }
    node.innerHTML = `<div class="table-wrap card flush"><table><thead><tr><th>Message</th><th>Channels</th><th>Status</th><th>Sent</th><th></th></tr></thead><tbody>${data.content.map((n) => `<tr>
      <td>${ui.escapeHtml(n.message)}</td><td>${ui.escapeHtml(n.deliveryChannels || "IN_APP")}</td><td>${ui.badge(n.status)}</td><td>${ui.datetime(n.sentDateTime)}</td>
      <td>${n.status !== "READ" ? `<button class="btn btn-small btn-ghost" data-read="${n.notificationId}">Mark read</button>` : "Read"}</td></tr>`).join("")}</tbody></table></div>`;
    ui.$all("[data-read]").forEach((button) => button.addEventListener("click", async () => {
      try { await window.Api.patch(`/notifications/${button.dataset.read}/read`, null); load(data.page); }
      catch (error) { ui.showAlert("#pageAlert", "error", ui.errorMessage(error)); }
    }));
  }
  async function load(page) {
    const data = await window.Api.get("/notifications/my", { page: page || 0, size: 10 });
    render(data); ui.pagination("#notificationsPagination", data, load);
  }
  document.addEventListener("DOMContentLoaded", () => { if (window.Auth.requireAuth()) load(0).catch((e) => ui.showAlert("#pageAlert", "error", ui.errorMessage(e))); });
})();
