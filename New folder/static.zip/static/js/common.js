(function () {
  const cfg = window.SmartRouteConfig;

  function $(selector, root) {
    return (root || document).querySelector(selector);
  }

  function $all(selector, root) {
    return Array.from((root || document).querySelectorAll(selector));
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function formatStatus(value) {
    return String(value || "")
      .toLowerCase()
      .split("_")
      .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
      .join(" ");
  }

  function statusClass(value) {
    const normalized = String(value || "").toLowerCase();
    if (["success", "confirmed", "scheduled", "available", "active", "resolved", "completed"].some((word) => normalized.includes(word))) return "status-success";
    if (["pending", "delayed", "progress", "assigned"].some((word) => normalized.includes(word))) return "status-warning";
    if (["failed", "cancelled", "inactive", "unavailable", "maintenance", "closed", "refunded"].some((word) => normalized.includes(word))) return "status-danger";
    return "status-muted";
  }

  function badge(value) {
    return `<span class="status-pill ${statusClass(value)}">${escapeHtml(formatStatus(value))}</span>`;
  }

  function money(value) {
    const n = Number(value || 0);
    return "LKR " + n.toLocaleString("en-LK", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  function date(value) {
    if (!value) return "-";
    return new Date(value + (String(value).includes("T") ? "" : "T00:00:00")).toLocaleDateString("en-LK", {
      year: "numeric",
      month: "short",
      day: "2-digit"
    });
  }

  function time(value) {
    if (!value) return "-";
    const [hh, mm] = String(value).split(":");
    const d = new Date();
    d.setHours(Number(hh || 0), Number(mm || 0), 0, 0);
    return d.toLocaleTimeString("en-LK", { hour: "2-digit", minute: "2-digit" });
  }

  function datetime(value) {
    if (!value) return "-";
    return new Date(value).toLocaleString("en-LK", {
      year: "numeric",
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit"
    });
  }

  function fullName(user) {
    if (!user) return "-";
    return [user.firstName, user.lastName].filter(Boolean).join(" ") || user.email || "-";
  }

  function routeLabel(schedule) {
    if (!schedule || !schedule.route) return "-";
    return `${schedule.route.origin} to ${schedule.route.destination}`;
  }

  function seatsLabel(seats) {
    return (seats || []).map((seat) => seat.seatNumber || seat).sort((a, b) => Number(a) - Number(b)).join(", ");
  }

  function setText(selector, text, root) {
    const node = $(selector, root);
    if (node) node.textContent = text;
  }

  function showAlert(target, type, message) {
    const node = typeof target === "string" ? $(target) : target;
    if (!node) return;
    node.innerHTML = message
      ? `<div class="alert alert-${type}" role="alert">${escapeHtml(message)}</div>`
      : "";
  }

  function errorMessage(error) {
    return error && error.message ? error.message : "Something went wrong. Please try again.";
  }

  function setLoading(button, loading, text) {
    if (!button) return;
    if (loading) {
      button.dataset.originalText = button.textContent;
      button.disabled = true;
      button.innerHTML = `<span class="spinner" aria-hidden="true"></span>${escapeHtml(text || "Loading")}`;
    } else {
      button.disabled = false;
      button.textContent = button.dataset.originalText || text || "Submit";
    }
  }

  function required(value) {
    return value !== undefined && value !== null && String(value).trim() !== "";
  }

  function validateEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || "").trim());
  }

  function validatePhone(value) {
    return !value || /^[0-9+()\-\s]{7,30}$/.test(String(value).trim());
  }

  function validatePassword(value) {
    return /^(?=.*[A-Za-z])(?=.*\d).{8,100}$/.test(String(value || ""));
  }

  function renderFieldErrors(errors) {
    $all(".field-error").forEach((node) => (node.textContent = ""));
    Object.entries(errors || {}).forEach(([field, message]) => {
      const target = document.querySelector(`[data-error-for="${field}"]`);
      if (target) target.textContent = message;
    });
  }

  function formData(form) {
    return Object.fromEntries(new FormData(form).entries());
  }

  function selectOptions(values, selected, includeBlank) {
    const blank = includeBlank ? `<option value="">${typeof includeBlank === "string" ? includeBlank : "Select"}</option>` : "";
    return blank + values.map((value) => `<option value="${escapeHtml(value)}"${value === selected ? " selected" : ""}>${escapeHtml(formatStatus(value))}</option>`).join("");
  }

  function pagination(container, page, onChange) {
    const node = typeof container === "string" ? $(container) : container;
    if (!node || !page || page.totalPages <= 1) {
      if (node) node.innerHTML = "";
      return;
    }
    const current = Number(page.page || 0);
    const last = Number(page.totalPages || 1) - 1;
    const pages = [];
    const start = Math.max(0, current - 2);
    const end = Math.min(last, current + 2);
    pages.push(`<button class="page-btn" data-page="${current - 1}" ${current === 0 ? "disabled" : ""}>Previous</button>`);
    for (let i = start; i <= end; i++) {
      pages.push(`<button class="page-btn ${i === current ? "active" : ""}" data-page="${i}">${i + 1}</button>`);
    }
    pages.push(`<button class="page-btn" data-page="${current + 1}" ${current >= last ? "disabled" : ""}>Next</button>`);
    node.innerHTML = pages.join("");
    $all("button[data-page]", node).forEach((button) => {
      button.addEventListener("click", () => {
        const next = Number(button.dataset.page);
        if (!Number.isNaN(next) && next >= 0 && next <= last) onChange(next);
      });
    });
  }

  function navLink(path, label, active) {
    return `<a class="nav-link ${active === path ? "active" : ""}" href="${path}">${label}</a>`;
  }

  function initShell() {
    const page = document.body.dataset.page || "";
    const nav = $("#siteNav");
    if (nav) {
      const user = window.Auth.getUser();
      const authenticated = window.Auth.isAuthenticated();
      const staff = window.Auth.isStaff();
      nav.innerHTML = `
        <nav class="navbar">
          <a class="brand" href="/index.html"><span class="brand-mark">SR</span><span>SmartRoute Lanka</span></a>
          <button class="nav-toggle" type="button" aria-label="Toggle navigation" aria-expanded="false">Menu</button>
          <div class="nav-menu">
            ${navLink("/index.html", "Home", page === "home" ? "/index.html" : "")}
            ${navLink("/search-results.html", "Schedules", page === "search" ? "/search-results.html" : "")}
            ${authenticated && !staff ? navLink("/my-bookings.html", "My bookings", page === "my-bookings" ? "/my-bookings.html" : "") : ""}
            ${authenticated ? navLink("/support.html", "Support", page === "support" ? "/support.html" : "") : ""}
            ${authenticated ? navLink("/notifications.html", "Notifications", page === "notifications" ? "/notifications.html" : "") : ""}
            ${staff ? navLink("/admin/dashboard.html", "Admin", "/admin/" + page + ".html") : ""}
          </div>
          <div class="nav-actions">
            ${authenticated ? `<a class="btn btn-ghost" href="/profile.html">${escapeHtml(fullName(user))}</a><button class="btn btn-primary" id="logoutBtn" type="button">Logout</button>` : `<a class="btn btn-ghost" href="/login.html">Login</a><a class="btn btn-primary" href="/register.html">Register</a>`}
          </div>
        </nav>`;
      const toggle = $(".nav-toggle", nav);
      const menu = $(".nav-menu", nav);
      toggle.addEventListener("click", () => {
        const open = menu.classList.toggle("open");
        toggle.setAttribute("aria-expanded", String(open));
      });
      const logout = $("#logoutBtn", nav);
      if (logout) logout.addEventListener("click", () => window.Auth.logout("/index.html"));
    }

    const adminNav = $("#adminNav");
    if (adminNav) {
      const role = window.Auth.currentRole();
      const links = [
        { href: "/admin/dashboard.html", label: "Dashboard", roles: cfg.staffRoles },
        { href: "/admin/users.html", label: "Users", roles: cfg.userAdminRoles },
        { href: "/admin/routes.html", label: "Routes", roles: cfg.transportRoles },
        { href: "/admin/buses.html", label: "Buses", roles: cfg.transportRoles },
        { href: "/admin/drivers.html", label: "Drivers", roles: cfg.transportRoles },
        { href: "/admin/schedules.html", label: "Schedules", roles: cfg.transportRoles },
        { href: "/admin/bookings.html", label: "Bookings", roles: cfg.supportRoles },
        { href: "/admin/payments.html", label: "Payments", roles: cfg.financeRoles },
        { href: "/admin/support-tickets.html", label: "Support tickets", roles: cfg.supportRoles },
        { href: "/admin/reviews.html", label: "Reviews & feedback", roles: cfg.supportRoles },
        { href: "/admin/reports.html", label: "Reports", roles: cfg.reportRoles }
      ].filter((link) => link.roles.includes(role));
      adminNav.innerHTML = `
        <aside class="admin-sidebar">
          <a class="brand compact" href="/admin/dashboard.html"><span class="brand-mark">SR</span><span>Admin</span></a>
          ${links.map((link) => `<a href="${link.href}">${link.label}</a>`).join("")}
          <a href="/index.html">Public site</a>
        </aside>`;
      const current = window.location.pathname;
      $all("a", adminNav).forEach((link) => {
        if (link.getAttribute("href") === current) link.classList.add("active");
      });
    }

    const footer = $("#siteFooter");
    if (footer) {
      footer.innerHTML = `<footer class="site-footer"><p>SmartRoute Lanka bus scheduling and booking system.</p><p>Secure bookings, verified schedules, and support for passengers and staff.</p></footer>`;
    }

    if (new URLSearchParams(window.location.search).get("forbidden")) {
      showAlert("#pageAlert", "warning", "You do not have permission to open that page.");
    }
  }

  document.addEventListener("DOMContentLoaded", initShell);

  window.SmartRoute = {
    $,
    $all,
    escapeHtml,
    formatStatus,
    statusClass,
    badge,
    money,
    date,
    time,
    datetime,
    fullName,
    routeLabel,
    seatsLabel,
    setText,
    showAlert,
    errorMessage,
    setLoading,
    required,
    validateEmail,
    validatePhone,
    validatePassword,
    renderFieldErrors,
    formData,
    selectOptions,
    pagination
  };
})();
