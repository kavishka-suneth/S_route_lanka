(function () {
  const ui = window.SmartRoute;
  const cfg = window.SmartRouteConfig;

  function pageName() {
    return document.body.dataset.adminPage;
  }

  function pageSize() {
    return cfg.defaultPageSize;
  }

  function unsupported(container, message) {
    ui.$(container).innerHTML = `<div class="empty-state">${ui.escapeHtml(message)}</div>`;
  }

  async function safeMetric(selector, label, loader, formatter) {
    try {
      const data = await loader();
      ui.$(selector).innerHTML = `<span>${ui.escapeHtml(label)}</span><strong>${ui.escapeHtml(formatter(data))}</strong>`;
    } catch (error) {
      ui.$(selector).innerHTML = `<span>${ui.escapeHtml(label)}</span><strong>Unavailable</strong>`;
    }
  }

  async function initDashboard() {
    await Promise.all([
      safeMetric("#metricUsers", "Total users", () => window.Api.get("/reports/users"), (d) => d.totalUsers),
      safeMetric("#metricBookings", "Total bookings", () => window.Api.get("/reports/bookings/count"), (d) => d.totalBookings),
      safeMetric("#metricRevenue", "Total revenue", () => window.Api.get("/reports/revenue/total"), (d) => ui.money(d.totalRevenue)),
      safeMetric("#metricPayments", "Successful payments", () => window.Api.get("/reports/payments"), (d) => d.successful),
      safeMetric("#metricSchedules", "Schedules", () => window.Api.get("/schedules", { size: 1 }), (d) => d.totalElements),
      safeMetric("#metricSupport", "Open support tickets", () => window.Api.get("/support-tickets", { status: "OPEN", size: 1 }), (d) => d.totalElements),
      safeMetric("#metricOccupancy", "Average occupancy", () => window.Api.get("/reports/schedule-occupancy", { size: 50 }), (d) => {
        const rows = d.content || [];
        if (!rows.length) return "0%";
        return (rows.reduce((sum, row) => sum + Number(row.occupancyPercent || 0), 0) / rows.length).toFixed(1) + "%";
      })
    ]);
  }

  function filterRows(rows, keyword, values) {
    if (!keyword) return rows;
    const needle = keyword.toLowerCase();
    return rows.filter((row) => values(row).join(" ").toLowerCase().includes(needle));
  }

  async function initUsers() {
    let currentPage = 0;
    let lastRows = [];

    async function load(page) {
      currentPage = page || 0;
      const role = ui.$("#roleFilter").value;
      const active = ui.$("#activeFilter").value;
      const data = await window.Api.get("/users", {
        role,
        active,
        page: currentPage,
        size: pageSize()
      });
      lastRows = data.content || [];
      render(data);
      ui.pagination("#adminPagination", data, load);
    }

    function render(data) {
      const keyword = ui.$("#userSearch").value.trim();
      const rows = filterRows(lastRows, keyword, (user) => [user.firstName, user.lastName, user.email, user.role]);
      if (!rows.length) {
        ui.$("#adminTable").innerHTML = `<div class="empty-state">No users found on this page.</div>`;
        return;
      }
      const canRole = window.Auth.hasRole("SYSTEM_ADMIN");
      const canActive = window.Auth.hasAny(["SYSTEM_ADMIN", "IT_SUPPORT"]);
      ui.$("#adminTable").innerHTML = `
        <div class="table-wrap card flush">
          <table>
            <thead><tr><th>User</th><th>Email</th><th>Phone</th><th>Role</th><th>Active</th><th>Actions</th></tr></thead>
            <tbody>${rows.map((user) => `
              <tr>
                <td>${ui.escapeHtml(ui.fullName(user))}</td>
                <td>${ui.escapeHtml(user.email)}</td>
                <td>${ui.escapeHtml(user.phone || "-")}</td>
                <td>
                  <select data-role="${user.userId}" ${canRole ? "" : "disabled"}>
                    ${cfg.roles.map((role) => `<option value="${role}"${role === user.role ? " selected" : ""}>${ui.formatStatus(role)}</option>`).join("")}
                  </select>
                </td>
                <td>${ui.badge(user.active ? "ACTIVE" : "INACTIVE")}</td>
                <td>
                  <div class="actions">
                    <button class="btn btn-small btn-ghost" data-view="${user.userId}" type="button">View</button>
                    <button class="btn btn-small btn-danger" data-active="${user.userId}" data-next="${!user.active}" type="button" ${canActive ? "" : "disabled"}>${user.active ? "Deactivate" : "Activate"}</button>
                  </div>
                </td>
              </tr>`).join("")}</tbody>
          </table>
        </div>`;
      ui.$all("[data-role]").forEach((select) => {
        select.addEventListener("change", async () => {
          if (!confirm("Change this user's role?")) return;
          try {
            await window.Api.patch(`/users/${select.dataset.role}/role`, { role: select.value });
            ui.showAlert("#pageAlert", "success", "Role updated.");
            load(currentPage);
          } catch (error) {
            ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
          }
        });
      });
      ui.$all("[data-active]").forEach((button) => {
        button.addEventListener("click", async () => {
          if (!confirm("Update this account active status?")) return;
          try {
            await window.Api.patch(`/users/${button.dataset.active}/active`, { active: button.dataset.next === "true" });
            ui.showAlert("#pageAlert", "success", "Account status updated.");
            load(currentPage);
          } catch (error) {
            ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
          }
        });
      });
      ui.$all("[data-view]").forEach((button) => {
        button.addEventListener("click", async () => {
          try {
            const user = await window.Api.get(`/users/${button.dataset.view}`);
            ui.$("#detailsPanel").innerHTML = `
              <h3>User details</h3>
              <div class="detail-grid">
                <div class="detail"><span>Name</span><strong>${ui.escapeHtml(ui.fullName(user))}</strong></div>
                <div class="detail"><span>Email</span><strong>${ui.escapeHtml(user.email)}</strong></div>
                <div class="detail"><span>Role</span><strong>${ui.escapeHtml(ui.formatStatus(user.role))}</strong></div>
                <div class="detail"><span>Passenger ID</span><strong>${ui.escapeHtml(user.passengerId || "-")}</strong></div>
                <div class="detail"><span>Staff ID</span><strong>${ui.escapeHtml(user.staffId || "-")}</strong></div>
                <div class="detail"><span>Created</span><strong>${ui.datetime(user.createdAt)}</strong></div>
              </div>`;
          } catch (error) {
            ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
          }
        });
      });
    }

    ui.$("#userSearch").addEventListener("input", () => render({ content: lastRows }));
    ui.$("#roleFilter").innerHTML = ui.selectOptions(cfg.roles, "", "All roles");
    ui.$("#roleFilter").addEventListener("change", () => load(0));
    ui.$("#activeFilter").addEventListener("change", () => load(0));
    load(0).catch((error) => ui.showAlert("#pageAlert", "error", ui.errorMessage(error)));
  }

  function crudTable(config) {
    let currentPage = 0;
    let rows = [];

    async function load(page) {
      currentPage = page || 0;
      const params = { page: currentPage, size: pageSize() };
      if (config.activeFilter) {
        const active = ui.$("#activeFilter").value;
        if (active !== "") params.active = active;
      }
      const data = await window.Api.get(config.path, params);
      rows = data.content || [];
      render(data);
      ui.pagination("#adminPagination", data, load);
    }

    function render(data) {
      const keywordNode = ui.$("#entitySearch");
      const keyword = keywordNode ? keywordNode.value.trim() : "";
      const visible = filterRows(rows, keyword, config.searchValues);
      if (!visible.length) {
        ui.$("#adminTable").innerHTML = `<div class="empty-state">No records found.</div>`;
        return;
      }
      ui.$("#adminTable").innerHTML = `
        <div class="table-wrap card flush">
          <table>
            <thead><tr>${config.columns.map((col) => `<th>${ui.escapeHtml(col.label)}</th>`).join("")}<th>Actions</th></tr></thead>
            <tbody>${visible.map((row) => `
              <tr>
                ${config.columns.map((col) => `<td>${col.render(row)}</td>`).join("")}
                <td>
                  <div class="actions">
                    <button class="btn btn-small btn-ghost" data-edit="${row[config.id]}">Edit</button>
                    <button class="btn btn-small btn-danger" data-delete="${row[config.id]}">${config.deleteLabel || "Delete"}</button>
                  </div>
                </td>
              </tr>`).join("")}</tbody>
          </table>
        </div>`;
      ui.$all("[data-edit]").forEach((button) => {
        button.addEventListener("click", () => {
          const row = rows.find((item) => String(item[config.id]) === button.dataset.edit);
          config.fill(row);
        });
      });
      ui.$all("[data-delete]").forEach((button) => {
        button.addEventListener("click", async () => {
          if (!confirm(config.confirmDelete || "Delete this record?")) return;
          try {
            await window.Api.delete(`${config.path}/${button.dataset.delete}`);
            ui.showAlert("#pageAlert", "success", config.deletedMessage || "Record updated.");
            load(currentPage);
          } catch (error) {
            ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
          }
        });
      });
    }

    const form = ui.$("#entityForm");
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const data = ui.formData(form);
      const payload = config.payload(data);
      const id = data[config.id];
      try {
        if (id) await window.Api.put(`${config.path}/${id}`, payload);
        else await window.Api.post(config.path, payload);
        form.reset();
        ui.$(`[name="${config.id}"]`).value = "";
        ui.showAlert("#pageAlert", "success", id ? "Record updated." : "Record created.");
        load(currentPage);
      } catch (error) {
        ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
      }
    });
    const clear = ui.$("#clearFormBtn");
    if (clear) clear.addEventListener("click", () => {
      form.reset();
      const idField = form.querySelector(`[name="${config.id}"]`);
      if (idField) idField.value = "";
    });
    const search = ui.$("#entitySearch");
    if (search) search.addEventListener("input", () => render({ content: rows }));
    const active = ui.$("#activeFilter");
    if (active) active.addEventListener("change", () => load(0));
    load(0).catch((error) => ui.showAlert("#pageAlert", "error", ui.errorMessage(error)));
  }

  function initRoutes() {
    crudTable({
      path: "/routes",
      id: "routeId",
      activeFilter: true,
      deleteLabel: "Deactivate",
      columns: [
        { label: "ID", render: (r) => r.routeId },
        { label: "Origin", render: (r) => ui.escapeHtml(r.origin) },
        { label: "Destination", render: (r) => ui.escapeHtml(r.destination) },
        { label: "Active", render: (r) => ui.badge(r.active ? "ACTIVE" : "INACTIVE") }
      ],
      searchValues: (r) => [r.origin, r.destination, r.active ? "active" : "inactive"],
      fill: (r) => {
        ui.$('[name="routeId"]').value = r.routeId;
        ui.$('[name="origin"]').value = r.origin;
        ui.$('[name="destination"]').value = r.destination;
        ui.$('[name="active"]').checked = Boolean(r.active);
      },
      payload: (d) => ({ origin: d.origin.trim(), destination: d.destination.trim(), active: d.active === "on" }),
      confirmDelete: "Deactivate this route? Existing schedules are preserved but passengers cannot book inactive routes.",
      deletedMessage: "Route deactivated."
    });
  }

  function initBuses() {
    ui.$('[name="busType"]').innerHTML = ui.selectOptions(cfg.busTypes, "STANDARD");
    ui.$('[name="availabilityStatus"]').innerHTML = ui.selectOptions(cfg.availabilityStatuses, "AVAILABLE");
    ui.$('[name="status"]').innerHTML = ui.selectOptions(cfg.busStatuses, "ACTIVE");
    crudTable({
      path: "/buses",
      id: "busId",
      activeFilter: true,
      deleteLabel: "Deactivate",
      columns: [
        { label: "Registration", render: (r) => ui.escapeHtml(r.registrationNo) },
        { label: "Capacity", render: (r) => `${r.capacity} seats` },
        { label: "Type", render: (r) => ui.formatStatus(r.busType) },
        { label: "Availability", render: (r) => ui.badge(r.availabilityStatus) },
        { label: "Status", render: (r) => ui.badge(r.status) }
      ],
      searchValues: (r) => [r.registrationNo, r.busType, r.status],
      fill: (r) => {
        ["busId", "registrationNo", "capacity", "busType", "availabilityStatus", "status"].forEach((name) => {
          ui.$(`[name="${name}"]`).value = r[name];
        });
      },
      payload: (d) => ({
        registrationNo: d.registrationNo.trim(),
        capacity: Number(d.capacity),
        busType: d.busType,
        availabilityStatus: d.availabilityStatus,
        status: d.status
      }),
      confirmDelete: "Deactivate this bus?"
    });
  }

  function initDrivers() {
    ui.$('[name="availabilityStatus"]').innerHTML = ui.selectOptions(cfg.availabilityStatuses, "AVAILABLE");
    crudTable({
      path: "/drivers",
      id: "driverId",
      activeFilter: true,
      deleteLabel: "Make unavailable",
      columns: [
        { label: "Name", render: (r) => ui.escapeHtml(`${r.firstName} ${r.lastName}`) },
        { label: "License", render: (r) => ui.escapeHtml(r.licenseNo) },
        { label: "Phone", render: (r) => ui.escapeHtml(r.phone || "-") },
        { label: "Availability", render: (r) => ui.badge(r.availabilityStatus) }
      ],
      searchValues: (r) => [r.firstName, r.lastName, r.licenseNo, r.phone, r.availabilityStatus],
      fill: (r) => {
        ["driverId", "firstName", "lastName", "licenseNo", "phone", "availabilityStatus"].forEach((name) => {
          ui.$(`[name="${name}"]`).value = r[name] || "";
        });
      },
      payload: (d) => ({
        firstName: d.firstName.trim(),
        lastName: d.lastName.trim(),
        licenseNo: d.licenseNo.trim(),
        phone: d.phone.trim(),
        availabilityStatus: d.availabilityStatus
      }),
      confirmDelete: "Mark this driver unavailable?"
    });
  }

  async function initSchedules() {
    let currentPage = 0;
    async function loadOptions() {
      const [routes, buses, drivers] = await Promise.all([
        window.Api.get("/routes", { size: 100 }),
        window.Api.get("/buses", { active: true, size: 100 }),
        window.Api.get("/drivers", { active: true, size: 100 })
      ]);
      ui.$('[name="routeId"]').innerHTML = `<option value="">Select route</option>` + (routes.content || []).map((r) => `<option value="${r.routeId}">${ui.escapeHtml(r.origin)} to ${ui.escapeHtml(r.destination)}</option>`).join("");
      ui.$('[name="busId"]').innerHTML = `<option value="">Select bus</option>` + (buses.content || []).map((b) => `<option value="${b.busId}">${ui.escapeHtml(b.registrationNo)} (${b.capacity})</option>`).join("");
      ui.$('[name="driverId"]').innerHTML = `<option value="">Select driver</option>` + (drivers.content || []).map((d) => `<option value="${d.driverId}">${ui.escapeHtml(d.firstName)} ${ui.escapeHtml(d.lastName)}</option>`).join("");
    }
    async function load(page) {
      currentPage = page || 0;
      const data = await window.Api.get("/schedules", { page: currentPage, size: pageSize() });
      if (!data.content.length) {
        ui.$("#adminTable").innerHTML = `<div class="empty-state">No schedules found.</div>`;
      } else {
        ui.$("#adminTable").innerHTML = `
          <div class="table-wrap card flush"><table>
            <thead><tr><th>Route</th><th>Date</th><th>Time</th><th>Bus</th><th>Driver</th><th>Fare</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>${data.content.map((s) => `
              <tr>
                <td>${ui.escapeHtml(ui.routeLabel(s))}</td>
                <td>${ui.date(s.travelDate)}</td>
                <td>${ui.time(s.departureTime)} - ${ui.time(s.arrivalTime)}</td>
                <td>${ui.escapeHtml(s.bus.registrationNo)}</td>
                <td>${ui.escapeHtml(s.driver.firstName)} ${ui.escapeHtml(s.driver.lastName)}</td>
                <td>${ui.money(s.fare)}</td>
                <td>${ui.badge(s.status)}</td>
                <td><div class="actions">
                  <button class="btn btn-small btn-ghost" data-edit="${s.scheduleId}">Edit</button>
                  <button class="btn btn-small btn-ghost" data-delay="${s.scheduleId}">Delay</button>
                  <button class="btn btn-small btn-danger" data-cancel="${s.scheduleId}">Cancel</button>
                </div></td>
              </tr>`).join("")}</tbody></table></div>`;
        ui.$all("[data-edit]").forEach((button) => {
          button.addEventListener("click", () => {
            const s = data.content.find((item) => String(item.scheduleId) === button.dataset.edit);
            ui.$('[name="scheduleId"]').value = s.scheduleId;
            ui.$('[name="routeId"]').value = s.route.routeId;
            ui.$('[name="busId"]').value = s.bus.busId;
            ui.$('[name="driverId"]').value = s.driver.driverId;
            ui.$('[name="travelDate"]').value = s.travelDate;
            ui.$('[name="departureTime"]').value = s.departureTime;
            ui.$('[name="arrivalTime"]').value = s.arrivalTime;
            ui.$('[name="fare"]').value = s.fare;
            ui.$('[name="status"]').value = s.status;
          });
        });
        async function statusUpdate(id, status) {
          try {
            await window.Api.patch(`/schedules/${id}/status`, { status });
            ui.showAlert("#pageAlert", "success", `Schedule ${ui.formatStatus(status).toLowerCase()}.`);
            load(currentPage);
          } catch (error) {
            ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
          }
        }
        ui.$all("[data-delay]").forEach((b) => b.addEventListener("click", () => statusUpdate(b.dataset.delay, "DELAYED")));
        ui.$all("[data-cancel]").forEach((b) => b.addEventListener("click", () => {
          if (confirm("Cancel this schedule and active bookings?")) statusUpdate(b.dataset.cancel, "CANCELLED");
        }));
      }
      ui.pagination("#adminPagination", data, load);
    }
    ui.$('[name="status"]').innerHTML = ui.selectOptions(cfg.scheduleStatuses, "SCHEDULED");
    await loadOptions();
    ui.$("#entityForm").addEventListener("submit", async (event) => {
      event.preventDefault();
      const d = ui.formData(event.currentTarget);
      const payload = {
        routeId: Number(d.routeId),
        busId: Number(d.busId),
        driverId: Number(d.driverId),
        travelDate: d.travelDate,
        departureTime: d.departureTime,
        arrivalTime: d.arrivalTime,
        fare: Number(d.fare),
        status: d.status
      };
      try {
        if (d.scheduleId) await window.Api.put(`/schedules/${d.scheduleId}`, payload);
        else await window.Api.post("/schedules", payload);
        event.currentTarget.reset();
        ui.showAlert("#pageAlert", "success", "Schedule saved.");
        load(currentPage);
      } catch (error) {
        ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
      }
    });
    load(0).catch((error) => ui.showAlert("#pageAlert", "error", ui.errorMessage(error)));
  }

  function renderBooking(booking, onChange) {
    ui.$("#lookupResult").innerHTML = `
      <div class="card">
        <h3>${ui.escapeHtml(booking.bookingReference)}</h3>
        <div class="detail-grid">
          <div class="detail"><span>Passenger</span><strong>${ui.escapeHtml(ui.fullName(booking.passengerUser))}</strong></div>
          <div class="detail"><span>Route</span><strong>${ui.escapeHtml(ui.routeLabel(booking.schedule))}</strong></div>
          <div class="detail"><span>Date</span><strong>${ui.date(booking.schedule.travelDate)} ${ui.time(booking.schedule.departureTime)}</strong></div>
          <div class="detail"><span>Seats</span><strong>${ui.escapeHtml(ui.seatsLabel(booking.seats))}</strong></div>
          <div class="detail"><span>Total</span><strong>${ui.money(booking.totalAmount)}</strong></div>
          <div class="detail"><span>Status</span>${ui.badge(booking.bookingStatus)}</div>
        </div>
        <div class="actions" style="margin-top:16px">
          <button class="btn btn-danger" id="adminCancelBooking" type="button">Cancel booking</button>
        </div>
      </div>`;
    ui.$("#adminCancelBooking").addEventListener("click", async () => {
      if (!confirm("Cancel this booking?")) return;
      try {
        const cancelled = await window.Api.patch(`/bookings/${booking.bookingId}/cancel`, null);
        renderBooking(cancelled, onChange);
        ui.showAlert("#pageAlert", "success", "Booking cancelled.");
        if (onChange) onChange(cancelled);
      } catch (error) {
        ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
      }
    });
  }

  function initBookingsAdmin() {
    let currentPage = 0;
    let rows = [];

    async function load(page) {
      currentPage = page || 0;
      const data = await window.Api.get("/bookings", {
        keyword: ui.$("#bookingKeyword").value.trim(),
        status: ui.$("#bookingStatusFilter").value,
        page: currentPage,
        size: pageSize()
      });
      rows = data.content || [];
      if (!rows.length) {
        ui.$("#adminTable").innerHTML = `<div class="empty-state">No bookings found.</div>`;
      } else {
        ui.$("#adminTable").innerHTML = `<div class="table-wrap card flush"><table>
          <thead><tr><th>ID</th><th>Reference</th><th>Passenger</th><th>Route</th><th>Date</th><th>Seats</th><th>Total</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>${rows.map((booking) => `<tr>
            <td>#${booking.bookingId}</td>
            <td>${ui.escapeHtml(booking.bookingReference)}</td>
            <td>${ui.escapeHtml(ui.fullName(booking.passengerUser))}</td>
            <td>${ui.escapeHtml(ui.routeLabel(booking.schedule))}</td>
            <td>${ui.date(booking.schedule.travelDate)} ${ui.time(booking.schedule.departureTime)}</td>
            <td>${ui.escapeHtml(ui.seatsLabel(booking.seats))}</td>
            <td>${ui.money(booking.totalAmount)}</td>
            <td>${ui.badge(booking.bookingStatus)}</td>
            <td><div class="actions">
              <button class="btn btn-small btn-ghost" data-view-booking="${booking.bookingId}" type="button">View</button>
              <button class="btn btn-small btn-danger" data-cancel-booking="${booking.bookingId}" type="button" ${["CANCELLED", "COMPLETED"].includes(booking.bookingStatus) ? "disabled" : ""}>Cancel</button>
            </div></td>
          </tr>`).join("")}</tbody></table></div>`;
        ui.$all("[data-view-booking]").forEach((button) => {
          button.addEventListener("click", () => {
            const booking = rows.find((item) => String(item.bookingId) === button.dataset.viewBooking);
            if (booking) renderBooking(booking, () => load(currentPage));
          });
        });
        ui.$all("[data-cancel-booking]").forEach((button) => {
          button.addEventListener("click", async () => {
            if (!confirm("Cancel this booking?")) return;
            try {
              const cancelled = await window.Api.patch(`/bookings/${button.dataset.cancelBooking}/cancel`, null);
              renderBooking(cancelled);
              ui.showAlert("#pageAlert", "success", "Booking cancelled.");
              load(currentPage);
            } catch (error) {
              ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
            }
          });
        });
      }
      ui.pagination("#adminPagination", data, load);
    }

    ui.$("#bookingStatusFilter").innerHTML = ui.selectOptions(cfg.bookingStatuses, "", "All statuses");
    ui.$("#bookingKeyword").addEventListener("input", () => load(0));
    ui.$("#bookingStatusFilter").addEventListener("change", () => load(0));
    ui.$("#refreshBookingsBtn").addEventListener("click", () => load(currentPage));
    load(0).catch((error) => ui.showAlert("#pageAlert", "error", ui.errorMessage(error)));

    ui.$("#bookingLookupForm").addEventListener("submit", async (event) => {
      event.preventDefault();
      const id = ui.formData(event.currentTarget).bookingId;
      try {
        renderBooking(await window.Api.get(`/bookings/${id}`), () => load(currentPage));
      } catch (error) {
        ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
      }
    });
  }

  function initPaymentsAdmin() {
    let currentPage = 0;
    let rows = [];

    function renderPaymentDetails(payment) {
      ui.$("#paymentResult").innerHTML = `<div class="card"><h3>Payment #${payment.paymentId}</h3><div class="detail-grid">
        <div class="detail"><span>Booking</span><strong>${ui.escapeHtml(payment.bookingReference)}</strong></div>
        <div class="detail"><span>Method</span><strong>${ui.escapeHtml(payment.paymentMethod)}</strong></div>
        <div class="detail"><span>Reference</span><strong>${ui.escapeHtml(payment.transactionReference)}</strong></div>
        <div class="detail"><span>Date</span><strong>${ui.datetime(payment.paymentDate)}</strong></div>
        <div class="detail"><span>Amount</span><strong>${ui.money(payment.amount)}</strong></div>
        <div class="detail"><span>Status</span>${ui.badge(payment.paymentStatus)}</div>
      </div><div class="actions" style="margin-top:16px"><button class="btn btn-danger" id="refundBtn" ${payment.paymentStatus === "SUCCESS" ? "" : "disabled"}>Refund</button></div></div>`;
      ui.$("#refundBtn").addEventListener("click", async () => {
        if (!confirm("Refund this successful payment?")) return;
        try {
          const refunded = await window.Api.post(`/payments/${payment.paymentId}/refund`, null);
          renderPaymentDetails(refunded);
          ui.showAlert("#pageAlert", "success", "Refund processed.");
          load(currentPage);
        } catch (error) {
          ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
        }
      });
    }

    async function load(page) {
      currentPage = page || 0;
      const data = await window.Api.get("/payments", {
        keyword: ui.$("#paymentKeyword").value.trim(),
        status: ui.$("#paymentStatusFilter").value,
        page: currentPage,
        size: pageSize()
      });
      rows = data.content || [];
      if (!rows.length) {
        ui.$("#adminTable").innerHTML = `<div class="empty-state">No payments found.</div>`;
      } else {
        ui.$("#adminTable").innerHTML = `<div class="table-wrap card flush"><table>
          <thead><tr><th>ID</th><th>Booking</th><th>Method</th><th>Reference</th><th>Date</th><th>Amount</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>${rows.map((payment) => `<tr>
            <td>#${payment.paymentId}</td>
            <td>${ui.escapeHtml(payment.bookingReference)}</td>
            <td>${ui.escapeHtml(payment.paymentMethod)}</td>
            <td>${ui.escapeHtml(payment.transactionReference)}</td>
            <td>${ui.datetime(payment.paymentDate)}</td>
            <td>${ui.money(payment.amount)}</td>
            <td>${ui.badge(payment.paymentStatus)}</td>
            <td><div class="actions">
              <button class="btn btn-small btn-ghost" data-view-payment="${payment.paymentId}" type="button">View</button>
              <button class="btn btn-small btn-danger" data-refund-payment="${payment.paymentId}" type="button" ${payment.paymentStatus === "SUCCESS" ? "" : "disabled"}>Refund</button>
            </div></td>
          </tr>`).join("")}</tbody></table></div>`;
        ui.$all("[data-view-payment]").forEach((button) => {
          button.addEventListener("click", () => {
            const payment = rows.find((item) => String(item.paymentId) === button.dataset.viewPayment);
            if (payment) renderPaymentDetails(payment);
          });
        });
        ui.$all("[data-refund-payment]").forEach((button) => {
          button.addEventListener("click", async () => {
            if (!confirm("Refund this successful payment?")) return;
            try {
              const refunded = await window.Api.post(`/payments/${button.dataset.refundPayment}/refund`, null);
              renderPaymentDetails(refunded);
              ui.showAlert("#pageAlert", "success", "Refund processed.");
              load(currentPage);
            } catch (error) {
              ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
            }
          });
        });
      }
      ui.pagination("#adminPagination", data, load);
    }

    ui.$("#paymentStatusFilter").innerHTML = ui.selectOptions(cfg.paymentStatuses, "", "All statuses");
    ui.$("#paymentKeyword").addEventListener("input", () => load(0));
    ui.$("#paymentStatusFilter").addEventListener("change", () => load(0));
    ui.$("#refreshPaymentsBtn").addEventListener("click", () => load(currentPage));
    load(0).catch((error) => ui.showAlert("#pageAlert", "error", ui.errorMessage(error)));

    ui.$("#paymentVerifyForm").addEventListener("submit", async (event) => {
      event.preventDefault();
      const id = ui.formData(event.currentTarget).paymentId;
      try {
        const payment = await window.Api.get(`/payments/${id}/verify`);
        renderPaymentDetails(payment);
      } catch (error) {
        ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
      }
    });
    ui.$("#receiptLookupForm").addEventListener("submit", async (event) => {
      event.preventDefault();
      const id = ui.formData(event.currentTarget).bookingId;
      try {
        const receipt = await window.Api.get(`/payments/bookings/${id}/receipt`);
        ui.$("#receiptResult").innerHTML = `<div class="card"><h3>${ui.escapeHtml(receipt.receiptNumber)}</h3><div class="detail-grid">
          <div class="detail"><span>Booking</span><strong>${ui.escapeHtml(receipt.bookingReference)}</strong></div>
          <div class="detail"><span>Passenger</span><strong>${ui.escapeHtml(receipt.passengerName)}</strong></div>
          <div class="detail"><span>Route</span><strong>${ui.escapeHtml(receipt.route)}</strong></div>
          <div class="detail"><span>Seats</span><strong>${ui.escapeHtml(ui.seatsLabel(receipt.seats))}</strong></div>
          <div class="detail"><span>Amount</span><strong>${ui.money(receipt.amount)}</strong></div>
          <div class="detail"><span>Transaction</span><strong>${ui.escapeHtml(receipt.transactionReference)}</strong></div>
        </div></div>`;
      } catch (error) {
        ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
      }
    });
  }

  async function initSupportAdmin() {
    async function load(page) {
      const data = await window.Api.get("/support-tickets", {
        status: ui.$("#statusFilter").value,
        unassigned: ui.$("#unassignedFilter").value,
        keyword: ui.$("#ticketKeyword").value.trim(),
        page: page || 0,
        size: pageSize()
      });
      if (!data.content.length) {
        ui.$("#adminTable").innerHTML = `<div class="empty-state">No support tickets found.</div>`;
      } else {
        ui.$("#adminTable").innerHTML = `<div class="table-wrap card flush"><table>
          <thead><tr><th>ID</th><th>Subject</th><th>Description</th><th>Status</th><th>Assign staff ID</th><th>Response</th><th>Actions</th></tr></thead>
          <tbody>${data.content.map((t) => `<tr>
            <td>#${t.ticketId}</td>
            <td>${ui.escapeHtml(t.subject)}</td>
            <td><div style="white-space:pre-wrap">${ui.escapeHtml(t.description)}</div></td>
            <td><select data-status="${t.ticketId}">${cfg.supportStatuses.map((s) => `<option value="${s}"${s === t.status ? " selected" : ""}>${ui.formatStatus(s)}</option>`).join("")}</select></td>
            <td><input data-staff="${t.ticketId}" type="number" min="1" value="${t.handledByStaffId || ""}" placeholder="Current staff"></td>
            <td><textarea data-response="${t.ticketId}" placeholder="Staff response"></textarea></td>
            <td><button class="btn btn-small btn-primary" data-respond="${t.ticketId}" type="button">Save response</button></td>
          </tr>`).join("")}</tbody></table></div>`;
        ui.$all("[data-respond]").forEach((button) => {
          button.addEventListener("click", async () => {
            const id = button.dataset.respond;
            try {
              await window.Api.patch(`/support-tickets/${id}/response`, {
                response: ui.$(`[data-response="${id}"]`).value.trim(),
                status: ui.$(`[data-status="${id}"]`).value,
                handledByStaffId: ui.$(`[data-staff="${id}"]`).value ? Number(ui.$(`[data-staff="${id}"]`).value) : null
              });
              ui.showAlert("#pageAlert", "success", "Ticket updated.");
              load(page || 0);
            } catch (error) {
              ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
            }
          });
        });
      }
      ui.pagination("#adminPagination", data, load);
    }
    ui.$("#statusFilter").innerHTML = ui.selectOptions(cfg.supportStatuses, "", "All statuses");
    ["statusFilter", "unassignedFilter"].forEach((id) => ui.$("#" + id).addEventListener("change", () => load(0)));
    ui.$("#ticketKeyword").addEventListener("input", () => load(0));
    load(0).catch((error) => ui.showAlert("#pageAlert", "error", ui.errorMessage(error)));
  }

  async function initReviews() {
    async function load(page) {
      try {
        const data = await window.Api.get("/reviews", { page: page || 0, size: pageSize() });
        ui.$("#adminTable").innerHTML = data.content.length ? `<div class="table-wrap card flush"><table><thead><tr><th>Review</th><th>Passenger</th><th>Booking</th><th>Rating</th><th>Feedback</th><th>Date</th></tr></thead><tbody>${data.content.map((r) => `<tr><td>#${r.reviewId}</td><td>#${r.passengerId}</td><td>#${r.bookingId}</td><td>${"★".repeat(r.rating)}${"☆".repeat(5 - r.rating)}</td><td>${ui.escapeHtml(r.comment || "No comment")}</td><td>${ui.datetime(r.reviewDate)}</td></tr>`).join("")}</tbody></table></div>` : '<div class="empty-state">No reviews found.</div>';
        ui.pagination("#adminPagination", data, load);
      } catch (error) { ui.showAlert("#pageAlert", "error", ui.errorMessage(error)); }
    }
    load(0);
  }

  async function initReports() {
    const exportButton = ui.$("#exportSummaryBtn");
    if (exportButton) {
      exportButton.addEventListener("click", async () => {
        try {
          ui.setLoading(exportButton, true, "Exporting");
          const response = await fetch(`${cfg.apiBase}/reports/export/summary.csv`, {
            headers: { Authorization: "Bearer " + window.Auth.getToken() }
          });
          if (!response.ok) throw new Error("Report export failed.");
          const blob = await response.blob();
          const url = URL.createObjectURL(blob);
          const link = document.createElement("a");
          link.href = url;
          link.download = "smartroute-report-summary.csv";
          document.body.appendChild(link);
          link.click();
          link.remove();
          URL.revokeObjectURL(url);
        } catch (error) {
          ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
        } finally {
          ui.setLoading(exportButton, false);
        }
      });
    }

    async function loadReports() {
      try {
        const [revenue, bookings, payments, users, cancelled, sales, occupancy] = await Promise.all([
          window.Api.get("/reports/revenue/total"),
          window.Api.get("/reports/bookings/count"),
          window.Api.get("/reports/payments"),
          window.Api.get("/reports/users"),
          window.Api.get("/reports/cancelled-bookings"),
          window.Api.get("/reports/ticket-sales"),
          window.Api.get("/reports/schedule-occupancy", { size: 10 })
        ]);
        ui.$("#reportsSummary").innerHTML = `
          <div class="summary-grid">
            <div class="card metric"><span>Total revenue</span><strong>${ui.money(revenue.totalRevenue)}</strong></div>
            <div class="card metric"><span>Total bookings</span><strong>${bookings.totalBookings}</strong></div>
            <div class="card metric"><span>Successful payments</span><strong>${payments.successful}</strong></div>
            <div class="card metric"><span>Users</span><strong>${users.totalUsers}</strong></div>
            <div class="card metric"><span>Cancelled bookings</span><strong>${cancelled.cancelledBookings}</strong></div>
            <div class="card metric"><span>Reserved seats</span><strong>${sales.activeReservedSeats}</strong></div>
          </div>`;
        const max = Math.max(...(occupancy.content || []).map((row) => row.occupancyPercent), 1);
        ui.$("#occupancyReport").innerHTML = `<div class="card"><h3>Schedule occupancy</h3><div class="bar-list">
          ${(occupancy.content || []).map((row) => `<div class="bar-row">
            <strong>${ui.escapeHtml(row.route)} (${ui.date(row.travelDate)} ${ui.time(row.departureTime)})</strong>
            <div class="bar-track"><div class="bar-fill" style="width:${Math.min(100, (row.occupancyPercent / max) * 100)}%"></div></div>
            <span class="muted">${row.reservedSeats}/${row.capacity} seats, ${row.occupancyPercent}%</span>
          </div>`).join("") || `<div class="empty-state">No occupancy data.</div>`}
        </div></div>`;
      } catch (error) {
        ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
      }
    }
    ui.$("#revenueRangeForm").addEventListener("submit", async (event) => {
      event.preventDefault();
      const d = ui.formData(event.currentTarget);
      try {
        const report = await window.Api.get("/reports/revenue", {
          from: new Date(d.from).toISOString(),
          to: new Date(d.to).toISOString()
        });
        ui.$("#rangeRevenue").innerHTML = `<div class="alert alert-info">Revenue in range: ${ui.money(report.totalRevenue)} from ${report.successfulPayments} successful payments.</div>`;
      } catch (error) {
        ui.showAlert("#pageAlert", "error", ui.errorMessage(error));
      }
    });
    loadReports();
  }

  document.addEventListener("DOMContentLoaded", () => {
    const adminPage = pageName();
    if (!adminPage) return;
    if (!window.Auth.requireAuth({ roles: cfg.staffRoles })) return;
    const init = {
      dashboard: initDashboard,
      users: initUsers,
      routes: initRoutes,
      buses: initBuses,
      drivers: initDrivers,
      schedules: initSchedules,
      bookings: initBookingsAdmin,
      payments: initPaymentsAdmin,
      "support-tickets": initSupportAdmin,
      reviews: initReviews,
      reports: initReports
    }[adminPage];
    if (init) init();
  });
})();
